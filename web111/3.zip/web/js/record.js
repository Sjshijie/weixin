$(function(){
		$("	.all_content ul .content .content_left").height($("	.all_content ul .content .content_right").height());
		
		$(".all_content ul .title div a").click(function(){
			$(".all_content ul .title div a").removeClass("cho");
			$(this).addClass("cho");
			if($(this).index()==1){
				$(".list").show();
				$(".scatter").hide();
			}else{
				$(".list").hide();
				$(".scatter").css("display","block");
			}
		})
})