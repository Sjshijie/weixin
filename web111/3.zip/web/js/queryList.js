$(function(){
	//下拉样式引用
	$('select.select').select();
	$(".query").click(function(){
		window.location.href="roomList.html";
	})
});
